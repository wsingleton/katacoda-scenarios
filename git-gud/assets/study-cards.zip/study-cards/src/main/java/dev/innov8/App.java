package dev.innov8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class App {

    public static boolean appRunning = true;

    public static void main( String[] args ) {

        try {

            while (appRunning) {
                String menuSelection = welcome();
                switch (menuSelection) {
                    case "1":
                        System.out.println("Login selected.");
                        break;
                    case "2":
                        System.out.println("Register selected.");
                        break;
                    case "3":
                        System.out.println("Explore selected.");
                        break;
                    case "4":
                        System.out.println("Exit selected");
                        appRunning = false;
                        break;
                    default:
                        System.out.println("Invalid selection made");
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static String welcome() throws IOException {

        System.out.print("Welcome to Study Cards!\n" +
                         "The application that allows for you to create and share flashcards for studying!\n\n" +

                         "What would you like to do?\n" +
                         "1) Login\n" +
                         "2) Register\n" +
                         "3) Explore\n" +
                         "4) Exit\n" +
                         "> ");

        return new BufferedReader(new InputStreamReader(System.in)).readLine();

    }

}
